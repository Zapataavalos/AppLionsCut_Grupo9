// Menú sticky al hacer scroll
window.addEventListener('scroll', function() {
  const header = document.querySelector('header');
  if (window.scrollY > 50) {
    header.style.background = 'rgba(0, 0, 0, 0.95)';
  } else {
    header.style.background = 'rgba(0, 0, 0, 0.8)';
  }
});

// Funcionalidad del carrito de compras
document.addEventListener('DOMContentLoaded', function() {
  const cartButtons = document.querySelectorAll('.btn-add-cart');
  const cartCountSpan = document.getElementById('cart-count');
  let cartItemCount = 0;

  cartButtons.forEach(button => {
    button.addEventListener('click', () => {
      cartItemCount++;
      cartCountSpan.textContent = cartItemCount;
      // Opcional: Muestra una pequeña alerta de confirmación
      alert('¡Producto añadido al carrito!');
    });
  });
});