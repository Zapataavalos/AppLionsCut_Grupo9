document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('nuevo-usuario-form');
    const runInput = document.getElementById('run');
    const nombreInput = document.getElementById('nombre');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    // ...y así con todos los campos que incluyas.

    // --- Funciones de Ayuda para Errores (reutilizadas) ---
    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error');
    };

    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error');
    };

    // --- Funciones de Validación (idénticas a las de registro.html) ---
    const validateRun = () => {
        const run = runInput.value.trim();
        clearError(runInput);
        if (run.length < 7 || run.length > 9) {
            showError(runInput, 'El RUN debe tener entre 7 y 9 caracteres.');
            return false;
        }
        return true;
    };
    
    const validateRequiredField = (input) => {
        const value = input.value.trim();
        clearError(input);
        if (value === '') {
            showError(input, 'Este campo es obligatorio.');
            return false;
        }
        return true;
    };
    
    const validateEmail = () => {
        const email = emailInput.value.trim();
        clearError(emailInput);
        const emailRegex = /^[^\s@]+@(?:duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
        if (!emailRegex.test(email)) {
            showError(emailInput, 'Usa un correo válido (@duoc.cl, @profesor.duoc.cl, @gmail.com).');
            return false;
        }
        return true;
    };
    
    const validatePassword = () => {
        const password = passwordInput.value.trim();
        clearError(passwordInput);
        if (password.length < 4 || password.length > 10) {
            showError(passwordInput, 'La contraseña debe tener entre 4 y 10 caracteres.');
            return false;
        }
        return true;
    };

    // Asignar eventos
    runInput.addEventListener('input', validateRun);
    nombreInput.addEventListener('input', () => validateRequiredField(nombreInput));
    // (Añadir listeners para los demás campos)
    emailInput.addEventListener('input', validateEmail);
    passwordInput.addEventListener('input', validatePassword);

    // Validación final
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        // Ejecutar todas las validaciones
        const isValid = validateRun() && validateRequiredField(nombreInput) && validateEmail() && validatePassword();
        
        if (isValid) {
            alert('¡Usuario guardado con éxito!');
            window.location.href = 'admin-usuarios.html';
        } else {
            alert('Por favor, corrige los errores.');
        }
    });
});