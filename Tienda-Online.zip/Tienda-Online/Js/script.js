// Espera a que todo el contenido del HTML se cargue antes de ejecutar el script.
document.addEventListener('DOMContentLoaded', () => {

    // --- LÓGICA DEL CARRITO DE COMPRAS ---

    // 1. Obtenemos el carrito guardado de localStorage o creamos uno nuevo si no existe.
    // JSON.parse() convierte el texto de localStorage de nuevo a un objeto JavaScript.
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // 2. Seleccionamos todos los botones "Añadir al Carrito".
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    const cartCountElement = document.getElementById('cart-count');

    // 3. Función para actualizar el contador del carrito en el header.
    function updateCartCount() {
        // La cantidad es el número de items en el array 'cart'.
        cartCountElement.textContent = cart.length;
    }

    // 4. Función para guardar el carrito en localStorage.
    function saveCart() {
        // JSON.stringify() convierte el objeto JavaScript a texto para poder guardarlo.
        localStorage.setItem('cart', JSON.stringify(cart));
    }

    // 5. Función para añadir un producto al carrito.
    function addToCart(productId, productName, productPrice) {
        // Creamos un objeto para el nuevo producto.
        const product = {
            id: productId,
            name: productName,
            price: productPrice,
        };

        // Añadimos el producto al array 'cart'.
        cart.push(product);

        // Actualizamos el contador y guardamos el carrito.
        updateCartCount();
        saveCart();

        // Damos una confirmación visual al usuario.
        alert(`"${productName}" se ha añadido al carrito.`);
    }

    // 6. Añadimos un "escuchador" de eventos a cada botón.
    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Obtenemos los datos del producto desde los atributos 'data-*' del botón.
            const productId = button.dataset.id;
            const productName = button.dataset.name;
            const productPrice = parseFloat(button.dataset.price); // Convertimos el precio a número

            addToCart(productId, productName, productPrice);
        });
    });

    // 7. Actualizamos el contador al cargar la página por primera vez.
    updateCartCount();

    // --- (Aquí irán las validaciones de formularios más adelante) ---

});