document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('checkout-form');
    // Seleccionamos todos los campos que vamos a validar
    const inputs = form.querySelectorAll('input[required]');

    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error');
    };

    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error');
    };

    const validateField = (input) => {
        clearError(input);
        if (input.value.trim() === '') {
            showError(input, 'Este campo no puede estar vacío.');
            return false;
        }
        return true;
    };

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        let isFormValid = true;
        // Validamos cada uno de los campos requeridos
        inputs.forEach(input => {
            if (!validateField(input)) {
                isFormValid = false;
            }
        });

        if (isFormValid) {
            // Si todo está correcto, mostramos el mensaje de éxito
            alert('¡Pago procesado con éxito! Gracias por tu compra.');
            
            // Vaciamos el carrito de compras del localStorage
            localStorage.removeItem('cart');
            
            // Redirigimos al usuario a la página de inicio
            window.location.href = 'index.html';
        } else {
            alert('Por favor, completa todos los campos del formulario.');
        }
    });

    // Añadimos validación en tiempo real para una mejor experiencia de usuario
    inputs.forEach(input => {
        input.addEventListener('input', () => validateField(input));
    });
});