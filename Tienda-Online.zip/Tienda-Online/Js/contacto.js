document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    const nombreInput = document.getElementById('nombre');
    const emailInput = document.getElementById('email');
    const comentarioInput = document.getElementById('comentario');

    // --- Funciones de Ayuda para Errores (reutilizadas) ---
    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error');
    };

    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error');
    };

    // --- Funciones de Validación Específicas ---

    // 1. Validar campo de texto requerido (para Nombre y Comentario)
    const validateRequiredField = (input) => {
        const value = input.value.trim();
        clearError(input);
        if (value === '') {
            showError(input, 'Este campo es obligatorio.');
            return false;
        }
        return true;
    };

    // 2. Validar Correo Electrónico (con los dominios permitidos)
    const validateEmail = () => {
        const email = emailInput.value.trim();
        clearError(emailInput);
        const emailRegex = /^[^\s@]+@(?:duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
        if (email === '') {
            showError(emailInput, 'El correo es obligatorio.');
            return false;
        }
        if (!emailRegex.test(email)) {
            showError(emailInput, 'Usa un correo válido (@duoc.cl, @profesor.duoc.cl, @gmail.com).');
            return false;
        }
        return true;
    };

    // Asignar eventos para validar en tiempo real
    nombreInput.addEventListener('input', () => validateRequiredField(nombreInput));
    emailInput.addEventListener('input', validateEmail);
    comentarioInput.addEventListener('input', () => validateRequiredField(comentarioInput));

    // Validación final al intentar enviar el formulario
    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevenir el envío automático

        const isNombreValid = validateRequiredField(nombreInput);
        const isEmailValid = validateEmail();
        const isComentarioValid = validateRequiredField(comentarioInput);

        if (isNombreValid && isEmailValid && isComentarioValid) {
            alert('¡Mensaje enviado con éxito!');
            form.reset(); // Limpia el formulario después de un envío exitoso
        } else {
            alert('Por favor, completa todos los campos correctamente.');
        }
    });
});