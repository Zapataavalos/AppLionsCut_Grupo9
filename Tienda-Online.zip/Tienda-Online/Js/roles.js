document.addEventListener('DOMContentLoaded', () => {
    // --- SIMULACIÓN DE ROLES DE USUARIO ---

    // 1. Simulamos el rol del usuario que ha iniciado sesión.
    // Puedes cambiar este valor a "Administrador", "Vendedor" o "Cliente" para probar los diferentes escenarios.
    const currentUserRole = 'Vendedor'; 

    // 2. Ocultamos los elementos del menú que no corresponden al rol.
    if (currentUserRole === 'Vendedor') {
        // Seleccionamos todos los elementos de la página que son solo para administradores.
        const adminElements = document.querySelectorAll('.admin-only');
        
        // Ocultamos cada uno de esos elementos.
        adminElements.forEach(element => {
            element.style.display = 'none';
        });
    }

    // 3. Lógica de redirección para roles no autorizados.
    // Si un cliente intenta acceder al panel de administración, lo redirigimos a la tienda.
    if (currentUserRole === 'Cliente') {
        alert("Acceso denegado. Debes ser administrador o vendedor para entrar aquí.");
        // Redirige al cliente a la página principal si intenta acceder al admin.
        window.location.href = 'index.html'; 
    }
});