document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    // --- Funciones de Ayuda (reutilizadas de la validación de registro) ---
    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error');
    };

    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error');
    };

    // --- Funciones de Validación Específicas del Login ---

    // 1. Validar Correo Electrónico
    const validateEmail = () => {
        const email = emailInput.value.trim();
        clearError(emailInput);
        // La misma validación que en el registro
        const emailRegex = /^[^\s@]+@(?:duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
        if (email === '') {
            showError(emailInput, 'El correo es obligatorio.');
            return false;
        }
        if (!emailRegex.test(email)) {
            showError(emailInput, 'Usa un correo válido (@duoc.cl, @profesor.duoc.cl, @gmail.com).');
            return false;
        }
        return true;
    };

    // 2. Validar Contraseña (según las reglas del PDF para el login)
    const validatePassword = () => {
        const password = passwordInput.value.trim();
        clearError(passwordInput);
        if (password === '') {
            showError(passwordInput, 'La contraseña es obligatoria.');
            return false;
        }
        // El PDF especifica de 4 a 10 caracteres para el login
        if (password.length < 4 || password.length > 10) {
            showError(passwordInput, 'La contraseña debe tener entre 4 y 10 caracteres.');
            return false;
        }
        return true;
    };
    
    // Asignar eventos para validar en tiempo real
    emailInput.addEventListener('input', validateEmail);
    passwordInput.addEventListener('input', validatePassword);

    // Validación final al intentar enviar el formulario
    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevenir el envío automático

        const isEmailValid = validateEmail();
        const isPasswordValid = validatePassword();

        if (isEmailValid && isPasswordValid) {
            alert('¡Login exitoso!');
            // En un proyecto real, aquí se verificarían los datos con el servidor.
            // Por ahora, podemos redirigir al home como simulación.
            window.location.href = 'index.html';
        } else {
            alert('Por favor, corrige los errores para ingresar.');
        }
    });
});