document.addEventListener('DOMContentLoaded', () => {
    // Seleccionar el formulario y sus campos
    const form = document.getElementById('registro-form');
    const runInput = document.getElementById('run');
    const nombreInput = document.getElementById('nombre');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const passwordConfirmInput = document.getElementById('password-confirm');

    // Función para mostrar errores
    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error'); // Añade clase para resaltar el campo
    };

    // Función para limpiar errores
    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error'); // Quita la clase de error
    };

    // --- FUNCIONES DE VALIDACIÓN ESPECÍFICAS ---

    // 1. Validar RUN
    const validateRun = () => {
        const run = runInput.value.trim();
        clearError(runInput);
        if (run.length < 7 || run.length > 9) {
            showError(runInput, 'El RUN debe tener entre 7 y 9 caracteres.');
            return false;
        }
        return true;
    };

    // 2. Validar Nombre (y otros campos de texto simples)
    const validateRequiredField = (input) => {
        const value = input.value.trim();
        clearError(input);
        if (value === '') {
            showError(input, 'Este campo es obligatorio.');
            return false;
        }
        return true;
    };
    
    // 3. Validar Correo Electrónico
    const validateEmail = () => {
        const email = emailInput.value.trim();
        clearError(emailInput);
        // Expresión regular para validar formato y dominios permitidos
        const emailRegex = /^[^\s@]+@(?:duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
        if (!emailRegex.test(email)) {
            showError(emailInput, 'Usa un correo válido (@duoc.cl, @profesor.duoc.cl, @gmail.com).');
            return false;
        }
        return true;
    };
    
    // 4. Validar Contraseña
    const validatePassword = () => {
        const password = passwordInput.value.trim();
        clearError(passwordInput);
        if (password.length < 4 || password.length > 10) {
            showError(passwordInput, 'La contraseña debe tener entre 4 y 10 caracteres.');
            return false;
        }
        return true;
    };
    
    // 5. Validar que las contraseñas coincidan
    const validatePasswordConfirm = () => {
        const password = passwordInput.value.trim();
        const confirmPassword = passwordConfirmInput.value.trim();
        clearError(passwordConfirmInput);
        if (password !== confirmPassword) {
            showError(passwordConfirmInput, 'Las contraseñas no coinciden.');
            return false;
        }
        return true;
    };

    // Asignar los "escuchadores" de eventos para validar en tiempo real
    runInput.addEventListener('input', validateRun);
    nombreInput.addEventListener('input', () => validateRequiredField(nombreInput));
    // (Añadir para apellidos y dirección también)
    emailInput.addEventListener('input', validateEmail);
    passwordInput.addEventListener('input', validatePassword);
    passwordConfirmInput.addEventListener('input', validatePasswordConfirm);

    // Validación final al intentar enviar el formulario
    form.addEventListener('submit', (event) => {
        // Prevenir el envío del formulario para hacer la validación final
        event.preventDefault(); 
        
        // Ejecutar todas las validaciones
        const isRunValid = validateRun();
        const isNombreValid = validateRequiredField(nombreInput);
        const isEmailValid = validateEmail();
        const isPasswordValid = validatePassword();
        const isPasswordConfirmValid = validatePasswordConfirm();

        // Si todas las validaciones son correctas, se puede enviar
        if (isRunValid && isNombreValid && isEmailValid && isPasswordValid && isPasswordConfirmValid) {
            alert('¡Formulario enviado con éxito!');
            // Aquí iría la lógica para enviar los datos a un servidor
            form.submit();
        } else {
            alert('Por favor, corrige los errores antes de enviar.');
        }
    });
});