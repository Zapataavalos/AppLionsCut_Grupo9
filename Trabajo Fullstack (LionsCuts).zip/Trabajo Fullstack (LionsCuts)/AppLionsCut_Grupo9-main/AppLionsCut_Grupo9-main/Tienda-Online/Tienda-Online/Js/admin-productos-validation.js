document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('nuevo-producto-form');
    const codigoInput = document.getElementById('codigo');
    const nombreInput = document.getElementById('nombre');
    const precioInput = document.getElementById('precio');
    const stockInput = document.getElementById('stock');

    // Funciones de ayuda para mostrar/limpiar errores
    const showError = (input, message) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = message;
        input.classList.add('error');
    };

    const clearError = (input) => {
        const errorElement = document.getElementById(`error-${input.id}`);
        errorElement.textContent = '';
        input.classList.remove('error');
    };

    // --- Funciones de Validación Específicas ---

    // 1. Validar campo de texto requerido (para código y nombre)
    const validateRequiredField = (input) => {
        clearError(input);
        if (input.value.trim() === '') {
            showError(input, 'Este campo es obligatorio.');
            return false;
        }
        return true;
    };

    // 2. Validar campo numérico positivo (para precio y stock)
    const validatePositiveNumber = (input) => {
        clearError(input);
        const value = parseFloat(input.value);

        if (isNaN(value)) {
            showError(input, 'Debe ingresar un número.');
            return false;
        }

        if (value < 0) {
            showError(input, 'El valor no puede ser negativo.');
            return false;
        }
        return true;
    };

    // Asignar eventos para validación en tiempo real
    codigoInput.addEventListener('input', () => validateRequiredField(codigoInput));
    nombreInput.addEventListener('input', () => validateRequiredField(nombreInput));
    precioInput.addEventListener('input', () => validatePositiveNumber(precioInput));
    stockInput.addEventListener('input', () => validatePositiveNumber(stockInput));

    // Validación final al enviar el formulario
    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const isCodigoValid = validateRequiredField(codigoInput);
        const isNombreValid = validateRequiredField(nombreInput);
        const isPrecioValid = validatePositiveNumber(precioInput);
        const isStockValid = validatePositiveNumber(stockInput);

        if (isCodigoValid && isNombreValid && isPrecioValid && isStockValid) {
            alert('¡Producto guardado con éxito!');
            // En un caso real, aquí se enviarían los datos.
            // Por ahora, redirigimos de vuelta a la lista de productos.
            window.location.href = 'admin-productos.html';
        } else {
            alert('Por favor, corrija los errores en el formulario.');
        }
    });
});