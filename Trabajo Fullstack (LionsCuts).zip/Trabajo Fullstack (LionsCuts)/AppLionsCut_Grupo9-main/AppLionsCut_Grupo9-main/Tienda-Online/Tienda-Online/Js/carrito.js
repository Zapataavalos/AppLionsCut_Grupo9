document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.getElementById('cart-items-container');
    const cartTotalElement = document.getElementById('cart-total');
    const clearCartBtn = document.getElementById('clear-cart-btn');

    // Cargar el carrito desde localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    function displayCartItems() {
        // Limpiar el contenedor antes de mostrar los items
        cartItemsContainer.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p>Tu carrito está vacío.</p>';
            cartTotalElement.textContent = '0';
            return;
        }

        cart.forEach(item => {
            // Crear el HTML para cada item del carrito
            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');
            itemElement.innerHTML = `
                <p>${item.name}</p>
                <p>$${item.price.toLocaleString('es-CL')}</p>
            `;
            cartItemsContainer.appendChild(itemElement);
            total += item.price;
        });

        // Actualizar el total en la página
        cartTotalElement.textContent = total.toLocaleString('es-CL');
    }

    // Función para vaciar el carrito
    function clearCart() {
        cart = []; // Vacía el array
        localStorage.removeItem('cart'); // Limpia el localStorage
        displayCartItems(); // Vuelve a mostrar el carrito (ahora vacío)
        // También actualizamos el contador del header (si estuviera en la misma página)
        // document.getElementById('cart-count').textContent = '0';
    }

    clearCartBtn.addEventListener('click', clearCart);

    // Mostrar los productos al cargar la página
    displayCartItems();
});