// Menú sticky al hacer scroll
window.addEventListener('scroll', function() {
  const header = document.querySelector('header');
  if (window.scrollY > 50) {
    header.style.background = 'rgba(0, 0, 0, 0.95)';
  } else {
    header.style.background = 'rgba(0, 0, 0, 0.8)';
  }
});

document.addEventListener('DOMContentLoaded', function() {
  // --- SELECTORES DE ELEMENTOS DEL DOM ---
  const cartModal = document.getElementById('cart-modal');
  const openCartBtn = document.getElementById('open-cart-btn');
  const closeBtn = document.querySelector('.close-btn');
  const addToCartButtons = document.querySelectorAll('.btn-add-cart');
  const cartCountSpan = document.getElementById('cart-count');
  const cartItemsContainer = document.getElementById('cart-items-container');
  const cartTotalPriceSpan = document.getElementById('cart-total-price');

  // Vistas del Modal
  const cartView = document.getElementById('cart-view');
  const checkoutView = document.getElementById('checkout-view');

  // Formularios
  const contactForm = document.querySelector('.contacto-form');
  const checkoutForm = document.getElementById('checkout-form');
  
  // Botones de acción
  const checkoutBtn = document.getElementById('checkout-btn');
  const backToCartBtn = document.getElementById('back-to-cart-btn');
  
  // Elementos del Formulario de pago
  const deliveryOptions = document.querySelectorAll('input[name="entrega"]');
  const addressContainer = document.getElementById('direccion-container');

  // --- ESTADO DEL CARRITO ---
  let cart = [];

  // --- FUNCIONES DE LOCALSTORAGE ---
  
  // Guarda el carrito actual en localStorage
  function saveCart() {
    localStorage.setItem('lionsCutsCart', JSON.stringify(cart));
  }

  // Carga el carrito desde localStorage al iniciar la página
  function loadCart() {
    const savedCart = localStorage.getItem('lionsCutsCart');
    if (savedCart) {
      cart = JSON.parse(savedCart);
    }
  }
  
  // --- MANEJO DE VISTAS Y EVENTOS ---
  
  openCartBtn.addEventListener('click', (e) => {
    e.preventDefault();
    showCartView();
    cartModal.style.display = 'block';
  });

  closeBtn.addEventListener('click', () => {
    cartModal.style.display = 'none';
  });

  window.addEventListener('click', (event) => {
    if (event.target == cartModal) {
      cartModal.style.display = 'none';
    }
  });
  
  checkoutBtn.addEventListener('click', () => {
    if (cart.length > 0) {
      showCheckoutView();
    } else {
      alert("Tu carrito está vacío. Añade productos antes de proceder al pago.");
    }
  });
  
  backToCartBtn.addEventListener('click', showCartView);

  addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
      const productElement = button.closest('.producto-item');
      const product = {
        id: productElement.dataset.id,
        name: productElement.dataset.name,
        price: parseInt(productElement.dataset.price, 10)
      };
      addProductToCart(product);
    });
  });
  
  // Evento para guardar datos del FORMULARIO DE CONTACTO en localStorage
  contactForm.addEventListener('submit', (e) => {
    // e.preventDefault(); // Descomenta si no quieres que la página se recargue
    const contactData = {
      nombre: document.getElementById('nombre').value,
      email: document.getElementById('email').value,
      mensaje: document.getElementById('mensaje').value,
    };
    localStorage.setItem('lionsCutsContactData', JSON.stringify(contactData));
    alert('¡Datos de contacto guardados en el almacenamiento local!');
  });
  
  // Evento para guardar datos del FORMULARIO DE PAGO en localStorage
  checkoutForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const nombre = document.getElementById('cliente-nombre').value;
    const apellidos = document.getElementById('cliente-apellidos').value;

    if (!nombre || !apellidos) {
        alert('Por favor, completa tu nombre y apellidos.');
        return;
    }

    const checkoutData = {
        nombre: nombre,
        apellidos: apellidos,
        rut: document.getElementById('cliente-rut').value,
        metodoEntrega: document.querySelector('input[name="entrega"]:checked').value,
        direccion: document.getElementById('cliente-direccion').value,
        // Por seguridad, nunca se guardan los datos de la tarjeta.
    };
    
    // Guardamos los datos del formulario en localStorage
    localStorage.setItem('lionsCutsCheckoutData', JSON.stringify(checkoutData));

    alert(`¡Gracias por tu compra, ${nombre}! Tus datos han sido guardados. (Simulación)`);
    cart = []; // Vaciar el carrito en el estado
    saveCart(); // Actualizar el localStorage con el carrito vacío
    updateCartUI(); // Actualizar la interfaz
    cartModal.style.display = 'none';
    checkoutForm.reset();
  });

  deliveryOptions.forEach(option => {
    option.addEventListener('change', () => {
      const isEnvio = document.querySelector('input[name="entrega"]:checked').value === 'envio';
      addressContainer.classList.toggle('hidden', !isEnvio);
    });
  });

  // --- FUNCIONES DEL CARRITO Y UI ---

  function showCartView() {
    cartView.classList.remove('hidden');
    checkoutView.classList.add('hidden');
  }

  function showCheckoutView() {
    cartView.classList.add('hidden');
    checkoutView.classList.remove('hidden');
  }

  function addProductToCart(product) {
    cart.push(product);
    updateCartUI();
    saveCart(); // Guardar en localStorage
  }

  function removeProductFromCart(productId) {
    const productIndex = cart.findIndex(item => item.id === productId);
    if (productIndex > -1) {
        cart.splice(productIndex, 1);
    }
    updateCartUI();
    saveCart(); // Guardar en localStorage
  }

  function updateCartUI() {
    cartItemsContainer.innerHTML = '';
    cartCountSpan.textContent = cart.length;
    let totalPrice = 0;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart-message">Tu carrito está vacío.</p>';
    } else {
        cart.forEach(product => {
            totalPrice += product.price;
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <div class="cart-item-details">
                    <h4>${product.name}</h4>
                    <p>${formatPrice(product.price)}</p>
                </div>
                <button class="remove-item-btn" data-id="${product.id}">&times;</button>
            `;
            cartItemsContainer.appendChild(cartItem);
        });
        
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.addEventListener('click', () => {
                const productId = button.dataset.id;
                removeProductFromCart(productId);
            });
        });
    }
    cartTotalPriceSpan.textContent = formatPrice(totalPrice);
  }
  
  function formatPrice(price) {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(price);
  }

  // --- INICIALIZACIÓN ---
  loadCart(); // Carga el carrito guardado tan pronto como la página está lista
  updateCartUI(); // Muestra el carrito cargado en la interfaz

  // GESTIÓN DE SESIÓN DE USUARIO
  const userSessionLi = document.getElementById('user-session-li');
  const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

  if (loggedInUser) {
      // Si hay un usuario logueado, muestra su nombre y un botón de "Cerrar Sesión"
      userSessionLi.innerHTML = `<a href="#" id="logout-btn">Cerrar Sesión (${loggedInUser.name})</a>`;
      
      const logoutBtn = document.getElementById('logout-btn');
      logoutBtn.addEventListener('click', (e) => {
          e.preventDefault();
          // Eliminar al usuario de localStorage y recargar la página
          localStorage.removeItem('loggedInUser');
          alert('Has cerrado la sesión.');
          window.location.reload();
      });
  } else {
      // Si no hay nadie logueado, muestra el enlace para "Acceder"
      userSessionLi.innerHTML = '<a href="acceso.html">Acceder</a>';
  }
});