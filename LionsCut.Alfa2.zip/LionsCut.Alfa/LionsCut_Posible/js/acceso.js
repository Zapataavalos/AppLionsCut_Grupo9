document.addEventListener('DOMContentLoaded', () => {
    // Selectores de Vistas
    const loginFormView = document.getElementById('login-form');
    const registerFormView = document.getElementById('register-form');

    // Selectores de Formularios
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');

    // Selectores de Enlaces para cambiar de vista
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');

    // --- MANEJO DE VISTAS ---

    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginFormView.classList.add('hidden');
        registerFormView.classList.remove('hidden');
    });

    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        registerFormView.classList.add('hidden');
        loginFormView.classList.remove('hidden');
    });

    // --- LÓGICA DE REGISTRO ---
    formRegister.addEventListener('submit', (e) => {
        e.preventDefault(); // Esta línea de JS previene que el formulario se envíe por defecto.

        // Obtenemos los valores de los inputs usando JS
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;

        // --- INICIO DE VALIDACIONES HECHAS CON JAVASCRIPT ---

        // 1. VALIDACIÓN DE CORREO con un 'if' en JS
        // La función de JS '.endsWith()' revisa si el texto del email termina con los dominios permitidos.
        if (!email.endsWith('@gmail.com') && !email.endsWith('@duoc.cl') && !email.endsWith('@profesor.duoc.cl')) {
            alert('Error: El correo debe ser @gmail.com, @duoc.cl o @profesor.duoc.cl');
            return; // 'return' detiene la ejecución de la función si la validación falla.
        }

        // 2. VALIDACIÓN DE CONTRASEÑA con un 'if' en JS
        // La propiedad de JS '.length' nos da el número de caracteres del password.
        if (password.length < 4 || password.length > 10) {
            alert('Error: La contraseña debe tener entre 4 y 10 caracteres.');
            return; // Detiene la ejecución si no cumple la condición.
        }

        // --- FIN DE VALIDACIONES ---

        // El resto del código solo se ejecuta si las validaciones de JS fueron exitosas
        const users = JSON.parse(localStorage.getItem('lionsCutsUsers')) || [];

        const userExists = users.some(user => user.email === email);
        if (userExists) {
            alert('El correo electrónico ya está registrado. Por favor, intenta con otro.');
            return;
        }

        const newUser = { name: document.getElementById('register-name').value, email, password };
        users.push(newUser);
        localStorage.setItem('lionsCutsUsers', JSON.stringify(users));

        alert('¡Registro exitoso! Ahora puedes iniciar sesión.');
        formRegister.reset();
        
        registerFormView.classList.add('hidden');
        loginFormView.classList.remove('hidden');
    });

    // --- LÓGICA DE INICIO DE SESIÓN ---
    formLogin.addEventListener('submit', (e) => {
        e.preventDefault();

        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        // Repetimos las mismas validaciones en JS para el login
        if (!email.endsWith('@gmail.com') && !email.endsWith('@duoc.cl') && !email.endsWith('@profesor.duoc.cl')) {
            alert('Error: El correo debe ser @gmail.com, @duoc.cl o @profesor.duoc.cl');
            return;
        }

        if (password.length < 4 || password.length > 10) {
            alert('Error: La contraseña debe tener entre 4 y 10 caracteres.');
            return;
        }

        // Si las validaciones son correctas, continuamos con la lógica de login
        const users = JSON.parse(localStorage.getItem('lionsCutsUsers')) || [];
        const userFound = users.find(user => user.email === email && user.password === password);

        if (userFound) {
            localStorage.setItem('loggedInUser', JSON.stringify(userFound));
            alert(`¡Bienvenido de vuelta, ${userFound.name}!`);
            window.location.href = 'index.html';
        } else {
            alert('Email o contraseña incorrectos. Por favor, inténtalo de nuevo.');
        }
    });
});